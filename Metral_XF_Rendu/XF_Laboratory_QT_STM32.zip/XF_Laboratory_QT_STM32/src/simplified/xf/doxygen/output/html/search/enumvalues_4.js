var searchData=
[
  ['notconsumed_199',['NotConsumed',['../class_x_f_event_status.html#ac34e2c129013264955388a63de39520fa619ade43444917a3cbbd0d806614a007',1,'XFEventStatus']]]
];
