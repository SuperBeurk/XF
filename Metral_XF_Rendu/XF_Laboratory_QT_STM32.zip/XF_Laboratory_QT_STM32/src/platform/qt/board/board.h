#ifndef BOARD_BOARD_H
#define BOARD_BOARD_H

#include <QCoreApplication>

namespace board {

void initialize();

}

#endif // BOARD_BOARD_H
