var searchData=
[
  ['terminate_201',['Terminate',['../class_x_f_event.html#a944826b381ee833ffddd30342088bf91a05421c9d2b62f31c8aff06a0a9013dc7',1,'XFEvent::Terminate()'],['../class_x_f_event_status.html#ac34e2c129013264955388a63de39520fa8d3b26da0a8fd77cdb2af2e9a18d954b',1,'XFEventStatus::Terminate()']]],
  ['timeout_202',['Timeout',['../class_x_f_event.html#a944826b381ee833ffddd30342088bf91a04f01a94d013ac0b3cd810b556427496',1,'XFEvent']]]
];
