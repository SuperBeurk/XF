var searchData=
[
  ['status_5f_187',['status_',['../class_x_f_event_status.html#a44a906459a1d26817a6eceb46c6514f7',1,'XFEventStatus']]]
];
