var searchData=
[
  ['front_124',['front',['../classinterface_1_1_x_f_event_queue.html#af3ef1cee72ec0c443bdc2650efb86133',1,'interface::XFEventQueue::front()'],['../class_x_f_event_queue.html#a91c78f3845e8f4d128ae4b25241c09ec',1,'XFEventQueue::front() override'],['../class_x_f_event_queue.html#a64640ed789cf22f1789cf298e266e70c',1,'XFEventQueue::front() override']]]
];
