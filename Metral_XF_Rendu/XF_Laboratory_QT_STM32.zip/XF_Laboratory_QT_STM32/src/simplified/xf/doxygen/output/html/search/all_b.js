var searchData=
[
  ['newevents_5f_44',['newEvents_',['../class_x_f_event_queue.html#a374c189f0ffd430963a87ce4c75d28b4',1,'XFEventQueue']]],
  ['notconsumed_45',['NotConsumed',['../class_x_f_event_status.html#ac34e2c129013264955388a63de39520fa619ade43444917a3cbbd0d806614a007',1,'XFEventStatus']]]
];
