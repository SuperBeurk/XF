#include "board.h"

namespace board {

void initialize()
{

}

} // namespace board
