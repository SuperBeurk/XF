var searchData=
[
  ['getbehavior_25',['getBehavior',['../class_x_f_event.html#a3a73a3d804420153b80a88274026d5f7',1,'XFEvent']]],
  ['getcurrentevent_26',['getCurrentEvent',['../class_x_f_behavior.html#afebc54c4c25d6660272992b888dd8175',1,'XFBehavior']]],
  ['getcurrenttimeout_27',['getCurrentTimeout',['../class_x_f_behavior.html#a526e40833adaceb46ce894985e497d55',1,'XFBehavior']]],
  ['getdispatcher_28',['getDispatcher',['../class_x_f_behavior.html#a357b7589b7f33c183303f6762e000cc1',1,'XFBehavior']]],
  ['geteventtype_29',['getEventType',['../class_x_f_event.html#abce814f103406c0a78cad6dd394ac567',1,'XFEvent']]],
  ['getinstance_30',['getInstance',['../classinterface_1_1_x_f_dispatcher.html#a2f654b19fdb7dc8e770d546ab654674f',1,'interface::XFDispatcher::getInstance()'],['../classinterface_1_1_x_f_timeout_manager.html#a9b8a25fcda13f06bd19bc2d66d21092e',1,'interface::XFTimeoutManager::getInstance()']]],
  ['gettickinterval_31',['getTickInterval',['../classinterface_1_1_x_f_timeout_manager.html#a905ce79bdbb26c7764b7e258c1b6d85c',1,'interface::XFTimeoutManager']]]
];
