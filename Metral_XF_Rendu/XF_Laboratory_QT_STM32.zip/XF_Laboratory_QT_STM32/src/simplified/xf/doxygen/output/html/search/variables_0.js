var searchData=
[
  ['_5fevents_167',['_events',['../class_x_f_dispatcher.html#aac23b7040b8a55dbcbe95a2cb341885a',1,'XFDispatcher']]],
  ['_5fmutex_168',['_mutex',['../class_x_f_event_queue.html#a060b8cf0d21d3c28bbf72e34d1e8fe64',1,'XFEventQueue']]],
  ['_5fpmutex_169',['_pMutex',['../class_x_f_dispatcher.html#aca140e0f9cc988393002fa620fe26aac',1,'XFDispatcher']]],
  ['_5fqueue_170',['_queue',['../class_x_f_event_queue.html#a892fe3703ca55fe92cd6ac6a599a7f43',1,'XFEventQueue']]]
];
